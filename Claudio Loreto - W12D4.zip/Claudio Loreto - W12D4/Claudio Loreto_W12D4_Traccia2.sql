-- W8-D5 -TEST FINALE SQL.
-- L'ESERCIZIO E' STATO REALIZZATO CON SQL SERVER MANAGMENT STUDIO.

-- CREAZIONE BASE DATI ToysGroup
CREATE DATABASE ToysGroup;

--------------------------CREAZIONE DELLA STRUTTRA PER LA BASE DATI ToysGroup.--------------------------

/*Task 2: Descrivi la struttura delle tabelle che reputi utili e sufficienti a modellare lo scenario proposto
tramite la sintassi DDL. Implementa fisicamente le tabelle utilizzando il DBMS SQL Server(o altro).**/
USE ToysGroup;

-- CREAZIONE DELLA TABELLA Categories.
CREATE TABLE Categories (
Id INT IDENTITY NOT NULL PRIMARY KEY,
Name NVARCHAR(150),
Sku NVARCHAR(50),
CreationDate DATETIME NOT NULL DEFAULT GETDATE(),
ObsoleteDate DATETIME,
LastModifiedDate DATETIME,
ActiveFlag BIT DEFAULT(1));

-- CREAZIONE DELLA TABELLA Products.
CREATE TABLE Products (
Id INT IDENTITY NOT NULL PRIMARY KEY,
Name NVARCHAR(150),
Sku NVARCHAR(50),
Description NVARCHAR(500),
Price DECIMAL(10, 2),
CreationDate DATETIME NOT NULL DEFAULT GETDATE(),
ObsoleteDate DATETIME,
LastModifiedDate DATETIME,
ActiveFlag BIT DEFAULT(1),
CategoryId INT NOT NULL,
FOREIGN KEY (CategoryId) REFERENCES Categories (Id) ON DELETE CASCADE);

-- CREAZIONE DELLA TABELLA Sales
CREATE TABLE Sales(
Id INT IDENTITY NOT NULL PRIMARY KEY,
Sku NVARCHAR(50),
SaleDate DATETIME NOT NULL DEFAULT GETDATE(),
LastModifiedDate DATETIME,
ObsoleteDate DATETIME,
ActiveFlag BIT DEFAULT(1));

-- CREAZIONE DELLA TABELLA States
CREATE TABLE States(
Id INT IDENTITY NOT NULL PRIMARY KEY,
Name NVARCHAR(150),
Sku NVARCHAR(50),
CreationDate DATETIME NOT NULL DEFAULT GETDATE());

-- CREAZIONE DELLA TABELLA Region 
CREATE TABLE Regions (
Id INT IDENTITY NOT NULL PRIMARY KEY,
Name NVARCHAR(150),
Sku NVARCHAR(50),
CreationDate DATETIME NOT NULL DEFAULT GETDATE());

-- CREAZIONE DELLA TABELLA SalesDetails
CREATE TABLE SalesDetails (
Id INT IDENTITY NOT NULL PRIMARY KEY,
SaleId INT NOT NULL,
ProductId INT NOT NULL,
DescriptionProduct NVARCHAR(500),
RegionId INT NOT NULL,
FOREIGN KEY (SaleId) REFERENCES Sales (Id) ON DELETE CASCADE,
FOREIGN KEY (ProductId) REFERENCES Products (Id) ON DELETE CASCADE,
FOREIGN KEY (RegionId) REFERENCES Regions (Id) ON DELETE CASCADE);

/*SE NON FOSSE ESPRESSAMENTE RICHIESTO DALLA TRACCIA, CHE OGNI ORDINE CONTIENE UN SOLO ARTICOLO, SAREBBE GIUSTO 
AGGIUNGERE A SalesDetails IL CAMPO Qta INT NOT NULL E IL CAMPO TotalSellingPrice DECIMAL(10, 2).**/

-- CREAZIONE DELLA TABELLA RegionDetails
CREATE TABLE RegionDetails (
Id INT IDENTITY NOT NULL PRIMARY KEY,
Sku NVARCHAR(50),
RegionId INT NOT NULL,
StateId INT NOT NULL,
FOREIGN KEY (RegionId) REFERENCES Regions (Id) ON DELETE CASCADE,
FOREIGN KEY (StateId) REFERENCES States (Id) ON DELETE CASCADE);

--------------------------POPOLAMENTO DELLA STRUTTRA PER LA BASE DATI ToysGroup.--------------------------

/*Task 3: Popola le tabelle utilizzando dati a tua discrezione (sono sufficienti pochi record per tabella;
riporta le query utilizzate)**/

-- POPOLAMENTO DELLA TABELLA Categories.
INSERT INTO Categories (Name,Sku)
VALUES 
('Giochi Educativi','CAT001'),
('Giochi di Societ�','CAT002'),
('Giochi d\Azione','CAT003'),
('Pupazzi', 'CAT004'),
('Giochi Tecnologici','CAT005'),
('Costruzioni','CAT006'),
('Veicoli Giocattolo','CAT007'),
('Giochi da Esterno','CAT008'),
('Giochi Creativi','CAT009'),
('Giochi da Tavolo','CAT010');

-- POPOLAMENTO DELLA TABELLA Products.
INSERT INTO Products (Name,Sku,Description,Price,CategoryId)
VALUES
('Puzzle 1000 pezzi','PROD001', 'Puzzle con tema natura',15.99,1),
('Monopoly','PROD002','Gioco di societ� classico',29.99,2),
('Spada laser','PROD003','Gioco d\azione con luci e suoni',24.99,3),
('Orsetto di peluche','PROD004','Orso di peluche morbido e coccoloso',19.99, 4),
('Robot telecomandato','PROD005','Robot interattivo con telecomando', 39.99,5),
('Set LEGO Star Wars','PROD006','Set di costruzioni LEGO a tema Star Wars',49.99,6),
('Macchina da corsa giocattolo','PROD007', 'Veicolo giocattolo telecomandato',34.99,7),
('Altalena da giardino','PROD008','Altalena per bambini da esterno',89.99,8),
('Kit pittura per bambini','PROD009','Set di pittura creativa per bambini',9.99,9),
('Scacchiera','PROD010','Gioco di scacchi in legno',39.99,10);

-- POPOLAMENTO DELLA TABELLA Sales
INSERT INTO Sales (Sku)
VALUES
('SALE001'),
('SALE002'),
('SALE003'),
('SALE004'),
('SALE005'),
('SALE006'),
('SALE007'),
('SALE008'),
('SALE009'),
('SALE010');

-- POPOLAMENTO DELLA TABELLA States
INSERT INTO States (Name,Sku)
VALUES
('California', 'ST001'),
('Francia', 'ST002'),
('Giappone', 'ST003'),
('Brasile', 'ST004'),
('Australia', 'ST005'), 
('Sudafrica', 'ST006'),
('Arabia Saudita', 'ST007'),
('Germania', 'ST008'),
('Argentina', 'ST009'),
('Nuova Zelanda', 'ST010');

-- POPOLAMENTO DELLA TABELLA Regions
INSERT INTO Regions (Name,Sku)
VALUES
('America del Nord', 'REG001'),
('Europa Occidentale', 'REG002'),
('Asia Orientale', 'REG003'),
('America Latina', 'REG004'),
('Australia', 'REG005'),
('Africa', 'REG006'),
('Medio Oriente', 'REG007'),
('Europa Centrale', 'REG008'),
('Sud America', 'REG009'),
('Oceania', 'REG010');

-- POPOLAMENTO DELLA TABELLA SalesDeta
INSERT INTO SalesDetails (SaleId,ProductId,DescriptionProduct,RegionId)
VALUES
(1, 1, 'Puzzle 1000 pezzi', 1),
(2, 2, 'Monopoly', 3),
(9, 3, 'Spada laser', 3),
(5, 4, 'Orsetto di peluche', 4),
(5, 5, 'Robot telecomandato', 1),
(5, 6, 'Set LEGO Star Wars', 1),
(1, 7, 'Macchina da corsa giocattolo', 7),
(10, 8, 'Altalena da giardino', 2),
(10, 10, 'Scacchiera', 10),
(7, 2, 'Monopoly', 2),
(1, 2, 'Monopoly', 6),
(2, 2, 'Monopoly', 3),
(4, 8, 'Altalena da giardino', 9),
(1, 7, 'Macchina da corsa giocattolo', 7);


-- POPOLAMENTO DELLA TABELLA RegionDetails
INSERT INTO RegionDetails (Sku,RegionId,StateId)
VALUES
('REGDET001', 1, 1),
('REGDET002', 2, 2),
('REGDET003', 3, 3),
('REGDET004', 4, 4),
('REGDET005', 5, 5),
('REGDET006', 6, 6),
('REGDET007', 7, 7),
('REGDET008', 8, 8),
('REGDET009', 9, 9),
('REGDET010', 10, 10);

--------------------------CREAZIONE VISTE E INTERROGAZIONE DELLA BASE DATI ToysGroup TRAMITE QUERY.--------------------------
/*Task 4: Dopo aver popolate le tabelle, scrivi delle query utili a: **/

/*1) Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare
l�univocit� dei valori di ciascuna PK (una query per tabella implementata).**/

/*LA QUERY DI ESEMPIO CHE SEGUE VIENE FATTA SOLO PER LA TABELLA Categories, MA PER VERIFICARE 
L'EFFETTIVA UNIVOCITA' DELLE PK, ANDREBBE FATTA PER OGNI TABELLA CREATA.
QUINDI SE LA QUERY NON TORNA RISULTATO ALLORA LE PK SONO UNIVOCHE ALTRIMENTI SONO DUPLICATE.
OLTRETUTTO PK SONO DEFINITE COME IDENTITY DUNQEU NON C'E' NESSUN TIPO DI PERICOLO**/ 
SELECT Id
       ,COUNT(*) AS NuberRow
  FROM Categories
  GROUP BY Id
 HAVING COUNT(*) > 1;

/*2) Esporre l�elenco delle transazioni indicando nel result set il codice documento, la data, il nome del
prodotto, la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo
booleano valorizzato in base alla condizione che siano passati pi� di 180 giorni dalla data vendita o
meno (>180 -> True, <= 180 -> False)**/
SELECT a.Sku AS	SkuSale
       ,a.SaleDate
       ,c.Name AS ProductName
       ,d.Name AS CategoriName
       ,g.Name AS StateName
       ,e.Name AS RegionName
       ,CASE 
            WHEN DATEDIFF(DAY, a.SaleDate, GETDATE()) > 180 THEN 1
            ELSE 0 
         END AS Flg180Days
  FROM Sales a
  JOIN SalesDetails b ON a.Id = b.SaleId
  JOIN Products c ON b.ProductId = c.Id
  JOIN Categories d ON c.CategoryId = d.Id
  JOIN Regions e ON b.RegionId = e.Id
  JOIN RegionDetails f ON e.Id = f.RegionId
  JOIN States g ON f.StateId = g.Id;

/*3) Esporre l�elenco dei prodotti che hanno venduto, in totale, una quantit� maggiore della media delle
vendite realizzate nell�ultimo anno censito. (ogni valore della condizione deve risultare da una query e
non deve essere inserito a mano). Nel result set devono comparire solo il codice prodotto e il totale
venduto**/
 SELECT a.Sku AS SkuProduct
        ,COUNT(*) AS SaleNumber
   FROM Products a
   JOIN SalesDetails b ON a.Id = b.ProductId
   JOIN Sales c ON b.SaleId =  c.Id 
   JOIN (SELECT MAX(YEAR(SaleDate)) AS LastYear
           FROM Sales) AS d ON d.LastYear = YEAR(c.SaleDate)-- ESTRAPOLO L'ANNO CON YEAR E VERFICO IL PIU' GRANDE CON LA MAX
  GROUP BY a.Sku
 HAVING COUNT(*) > (SELECT AVG(a.SaleNumber) -- MEDIA DEL NUMERO VENDITE RAGGRUPATE PEL PRODOTTO PER IL L'ULTIMO ANNO
                      FROM (SELECT c.Sku AS SkuProduct
                                   ,COUNT(*) AS SaleNumber
                              FROM Sales a
                              JOIN SalesDetails b ON a.Id = b.SaleId
                              JOIN Products c ON b.ProductId = c.Id
                              JOIN (SELECT MAX(YEAR(SaleDate)) AS LastYear
                                      FROM Sales) AS d ON d.LastYear = YEAR(a.SaleDate) -- ESTRAPOLO L'ANNO CON YEAR E VERFICO IL PIU' GRANDE CON LA MAX
                              GROUP BY c.Sku) AS a) -- NUMERO VENDITE RAGGRUPATE PEL PRODOTTO PER IL L'ULTIMO ANNO

/*4) Esporre l�elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno**/
SELECT c.Sku AS	SkuSale
       ,YEAR(b.SaleDate) AS SaleYear
       ,SUM(c.Price) AS TotalRevenue
  FROM SalesDetails a
  JOIN Sales b ON a.SaleId = b.Id
  JOIN Products c ON a.ProductId = c.Id
 GROUP BY c.Sku,YEAR(b.SaleDate)
 ORDER BY SaleYear, TotalRevenue DESC;

/*5) Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente**/
SELECT f.Name AS StateName,
       YEAR(b.SaleDate) AS SaleYears,
       SUM(c.Price) AS TotalSales
  FROM SalesDetails AS a
  JOIN Sales AS b ON a.SaleId = b.Id
  JOIN Products AS c ON a.ProductId = c.Id
  JOIN Regions AS d ON a.RegionId = d.Id
  JOIN RegionDetails AS e ON d.Id = e.RegionId
  JOIN States AS f ON e.StateId = f.Id
 GROUP BY f.Name,YEAR(b.SaleDate)
 ORDER BY SaleYears,TotalSales DESC;

-- IN ALTERNATIVA SE SI E' GIA' CREATA LA VISTA VwLocalities
SELECT d.StateName AS StateName,
       YEAR(b.SaleDate) AS SaleYears,
       SUM(c.Price) AS TotalSales
  FROM SalesDetails AS a
  JOIN Sales AS b ON a.SaleId = b.Id
  JOIN Products AS c ON a.ProductId = c.Id
  JOIN VwLocalities AS d ON a.RegionId = d.RegionId
 GROUP BY d.StateName,YEAR(b.SaleDate)
 ORDER BY SaleYears,TotalSales DESC;

/*6) Rispondere alla seguente domanda: qual � la categoria di articoli maggiormente richiesta dal mercato?**/
SELECT TOP 1 c.Name AS CategoryName,
       COUNT(*) AS SalesNumber
  FROM SalesDetails AS a
  JOIN Products b ON a.ProductId = b.Id
  JOIN Categories c ON b.CategoryId = c.Id
GROUP BY c.Name 
ORDER BY COUNT(*) DESC; 

/*7) Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.**/

-- APPROCCIO 1 LEFT JOIN
SELECT a.Name AS NameProduct
       ,a.Sku AS SkuProduct
  FROM Products AS a
  LEFT JOIN SalesDetails AS b on a.Id = b.ProductId
 WHERE b.Id IS NULL;

-- APPROCCIO 2 
SELECT Name
       ,Sku
  FROM Products
 WHERE Id NOT IN (SELECT ProductId 
                    FROM SalesDetails);

/*8) Creare una vista sui prodotti in modo tale da esporre una �versione denormalizzata� delle informazioni
utili (codice prodotto, nome prodotto, nome categoria)**/
CREATE VIEW [VwCategoriesProducts] AS
SELECT a.Sku  AS ProductSku
       ,a.Id AS ProductId
       ,a.Name AS ProductName
	   ,b.Id AS CategoryId
	   ,b.Name AS CategoryName
  FROM Products AS a
  JOIN Categories AS b ON a.CategoryId = b.Id;

/*9) Creare una vista per le informazioni geografiche.**/
CREATE VIEW [VwLocalities] AS
SELECT a.Sku AS LocalitySku
       ,b.Id AS RegionId
       ,b.Name AS RegioneName
	   ,b.Sku AS RegioneSku
	   ,c.Id AS StateId
	   ,c.Name AS StateName
	   ,c.Sku AS StateSku
  FROM RegionDetails AS a
  JOIN Regions AS b ON a.RegionId = b.Id
  JOIN States AS c ON a.StateId = c.Id;

